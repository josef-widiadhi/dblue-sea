
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True)
    acct_no = Column(String)
class Txn(Base):
    __tablename__ = "txn"
    id = Column(Integer, primary_key=True)
    src_acct = Column(String, ForeignKey("accounts.acct_no"))
    account = relationship("Account")
